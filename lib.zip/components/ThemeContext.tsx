import * as storage from "@/lib/storage";
import { STORAGE_KEYS } from '@/lib/storage';
import React, { createContext, ReactNode, useEffect, useState } from "react";

type ThemeContextType = {
  dark: boolean;
  toggleTheme: () => void;
}
export const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

type ProviderProps = {
  children: ReactNode;
};

export const ThemeProvider = ({ children }: ProviderProps) => {
  const [dark, setDark] = useState<boolean>(true);
  const toggleTheme = () => setDark(prev => !prev);
  useEffect(() => {
    const loadTheme = async () => {
      const saved = await storage.get<boolean>(STORAGE_KEYS.THEME);
      if (saved != null) {
        if (saved !== dark) {
          toggleTheme();
        }
      }
    }
    loadTheme();
  }, [])
  return (
    <ThemeContext.Provider value={{ dark, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};